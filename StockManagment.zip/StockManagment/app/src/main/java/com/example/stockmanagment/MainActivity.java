package com.example.stockmanagment;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener, View.OnClickListener {
    Spinner Name;
    TextView Price, Total;
    EditText Qty;
    Button Ok;

    String ProductName[] = {"Cheese", "Butter", "Mayo", "Paneer", "Butter Milk"};
    double ProductPrice[] = {3.7, 2.5, 2.3, 2.0, 0.8};
    int ProductQuantity[] = {15, 20, 12, 22, 17};
    public static double total = 0.0;
    public static double total1 = 0.0;
    public static double grandtotal1 = 0.0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //initializer
        Price = findViewById(R.id.tvPrice);
        Total = findViewById(R.id.tvTotal);
        Qty = findViewById(R.id.etxQty);
        Ok = findViewById(R.id.btnOk);
        Ok.setOnClickListener(this);
        Name = findViewById(R.id.spName);


        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, ProductName);

        Name.setAdapter(adapter);

        Name.setOnItemSelectedListener(this);
    }

    String selectedName;

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        Price.setText(String.valueOf(ProductPrice[position]));
        selectedName = ProductName[position];
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        Price.setText(String.valueOf(ProductPrice[0]));
    }

    @Override
    public void onClick(View v) {
        int selectedProductQuantity = 0;

        if (Qty.getText().toString().isEmpty())
        {
            Toast.makeText(getBaseContext(), " please enter required quantity", Toast.LENGTH_LONG).show();
        }
        else
            {
            int enteredQuantity = Integer.parseInt(Qty.getText().toString());
            for (int i = 0; i < ProductName.length-1; i++)
            {
                if (ProductName[i].equalsIgnoreCase(selectedName))
                {
                    selectedProductQuantity = ProductQuantity[i];
                }
            }
            if (selectedProductQuantity < enteredQuantity)
            {
                Toast.makeText(getBaseContext(), " No sufficient quantity", Toast.LENGTH_LONG).show();
            }
            else if(enteredQuantity<10)
            {
                int quantity = Integer.parseInt(Qty.getText().toString());
                double drinkPrice = Double.parseDouble(Price.getText().toString());
                total += drinkPrice * quantity;
                Total.setText(String.format("%.2f", total));
            }
             else
            {
                int quantity = Integer.parseInt(Qty.getText().toString());
                double drinkPrice = Double.parseDouble(Price.getText().toString());
                total += drinkPrice * quantity ;
                total1 = total * 0.05;
                grandtotal1 = total-total1;
                Total.setText(String.format("%.2f", grandtotal1));
            }
            }
    }
}